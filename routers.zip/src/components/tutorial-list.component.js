import React,{Component} from "react";
import {connect} from "react-redux";
import {Link} from "react-router-dom"
import {deleteAllTutorial} from "../slices/tutorials"

class TutorialsList extends Component{
  constructor(props) {
    super(props);
    this.removeAllTutorials=this.removeAllTutorials.bind(this);
    this.onChangeSearchTitle=this.onChangeSearchTitle.bind(this);
    this.refreshData=this.refreshData.bind(this)
    this.state = {
      currentTutorial: null,
      currentIndex: -1,
      searchTitle: "",
    };
  }

  onChangeSearchTitle(e) {
    const searchTitle = e.target.value;
    this.setState({
      searchTitle: searchTitle,
    });
  }

  refreshData() {
    this.setState({
      currentTutorial: null,
      currentIndex: -1,
    });
  }

  setActiveTutorial(tutorial, index) {
    this.setState({
      currentTutorial: tutorial,
      currentIndex: index,
    });
  }

  removeAllTutorials(){
    var txt = `Are you sure for remove all files`;
    if (window.confirm(txt)) {
      var val = true;
    } else {
      var val = false;
    }
     if(val==true){
       this.props.dispatch(deleteAllTutorial())
        this.refreshData()
     }
  };


  findByTitle() {
    this.refreshData();
    this.props.findTutorialsByTitle({ title: this.state.searchTitle });
  }
  // const dataTable = () => {
  //   let Val = [];
  //   Val =
  //     array &&
  //     array.filter(
  //       (item) =>
  //         item.name.toLowerCase().startsWith(search.toLowerCase()) ||
  //         item.email.toLowerCase().startsWith(search.toLowerCase()) ||
  //         item.mobileNo.toLowerCase().startsWith(search.toLowerCase())
  //     );

  //   // console.log(Val, "Val");

  //   const FilteredData = Val.map((item) => {
  //     return (
  //       <>
  //         <tr>
  //           <td>{item.id}</td>
  //           <td>{item.name}</td>
  //           <td>{item.email}</td>
  //           <td>{item.mobileNo}</td>
  //         </tr>
  //       </>
  //     );
  //   });
  //   return FilteredData;
  // };

  render(){ 
    const { searchTitle, currentTutorial, currentIndex } = this.state;
    const {tutorials}=this.props

    return(
      <>
       <div className="list row">
        <div className="col-md-8">
          <div className="input-group mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Search by title"
              value={searchTitle}
              onChange={this.onChangeSearchTitle}
            />
            <div className="input-group-append">
              <button
                className="btn btn-outline-secondary"
                type="button"
                onClick={this.findByTitle}
              >
                Search
              </button>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <h4>Tutorials List</h4>
          <ul className="list-group">
            {tutorials &&
              tutorials.map((tutorial, index) => (
                <li
                  className={
                    "list-group-item " +
                    (index === currentIndex ? "active" : "")
                  }
                  onClick={() => this.setActiveTutorial(tutorial, index)}
                  key={index}
                >
                  {tutorial.title}
                </li>
              ))}
          </ul>
          <button
            className="m-3 btn btn-sm btn-danger"
            onClick={this.removeAllTutorials}
          >
            Remove All
          </button>
        </div>
        <div className="col-md-6">
          {currentTutorial ? (
            <div>
              <h4>Tutorial</h4>
              <div>
                <label>
                  <strong>Title:</strong>
                </label>{" "}
                {currentTutorial.title}
              </div>
              <div>
                <label>
                  <strong>Description:</strong>
                </label>{" "}
                {currentTutorial.description}
              </div>
              <div>
                <label>
                  <strong>Status:</strong>
                </label>{" "}
                {currentTutorial.published ? "Published" : "Pending"}
              </div>
              <Link
                to={"/tutorials/" + currentTutorial.id}
                className="badge badge-warning"
              >
                Edit
              </Link>
            </div>
          ) : (
            <div>
              <br />
              <p>Please click on a Tutorial...</p>
            </div>
          )}
        </div>
        </div>
      </>
    )
  }
}
const mapStateToProps = (state) => {
  return {
      tutorials: state.tutorial.data,
      // deleteAllTutorial
  };
}

export default connect(mapStateToProps,null)(TutorialsList);